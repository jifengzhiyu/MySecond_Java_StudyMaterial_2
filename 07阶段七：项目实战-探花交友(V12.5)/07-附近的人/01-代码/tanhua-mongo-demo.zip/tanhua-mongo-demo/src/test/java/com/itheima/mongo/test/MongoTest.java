package com.itheima.mongo.test;

import com.itheima.mongo.domain.Places;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.geo.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MongoTest {

    @Autowired
    private MongoTemplate mongoTemplate;


    //查询附近
    @Test
    public void testNear() {
        //1、构造中心点(圆点)
        GeoJsonPoint point = new GeoJsonPoint(116.404, 39.915);
        //2、绘制半径
        Distance distance = new Distance(1, Metrics.KILOMETERS);//距离，距离的单位
        //3、绘制圆
        Circle circle = new Circle(point,distance);
        //4、构建query
        Query query = Query.query(Criteria.where("location").withinSphere(circle));
        //5、查询
        List<Places> list = mongoTemplate.find(query, Places.class);
        for (Places places : list) {
            System.out.println(places);
        }
    }

    //查询附近且获取间距
    @Test
    public void testNear1() {
        //1、构造中心点(圆点)
        GeoJsonPoint point = new GeoJsonPoint(116.404, 39.915);
        //2、构建NearQuery对象
        NearQuery query = NearQuery.near(point, Metrics.KILOMETERS).maxDistance(1, Metrics.KILOMETERS);
        //3、调用mongoTemplate的geoNear方法查询
        GeoResults<Places> results = mongoTemplate.geoNear(query, Places.class);
        //4、解析GeoResult对象，获取距离和数据
        for (GeoResult<Places> result : results) {
            Places places = result.getContent();
            double value = result.getDistance().getValue();
            System.out.println(places+"---距离："+value + "km");
        }
    }
}
