package com.tanhua.autoconfig.template;


import cn.hutool.http.Header;
import cn.hutool.http.HttpRequest;
import com.tanhua.autoconfig.properties.SmsProperties;

import java.util.HashMap;
import java.util.Map;

public class SmsTemplate {

    private SmsProperties properties;

    public SmsTemplate (SmsProperties properties) {
        this.properties = properties;
    }

    public void sendSms(String mobile,String code) {

        //请求连接
        String host = "https://gyytz.market.alicloudapi.com/sms/smsSend";
        //拼装请求体
        Map<String, Object> querys = new HashMap<String, Object>();
        querys.put("mobile", mobile);
        querys.put("param", "**code**:"+code+",**minute**:5");
        querys.put("smsSignId", properties.getSmsSignId());
        querys.put("templateId", properties.getTemplateId());

        try {
            String result = HttpRequest.post(host)
                    .header(Header.AUTHORIZATION, "APPCODE " + properties.getAppcode())//头信息，多个头信息多次调用此方法即可
                    .form(querys)//表单内容
                    .timeout(20000)//超时，毫秒
                    .execute().body();
            System.out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
