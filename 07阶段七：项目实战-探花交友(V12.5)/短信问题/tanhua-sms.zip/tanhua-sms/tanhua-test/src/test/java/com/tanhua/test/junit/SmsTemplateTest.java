package com.tanhua.test.junit;

import com.tanhua.autoconfig.template.SmsTemplate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 测试组件
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class SmsTemplateTest {

    //注入template
    @Autowired
    private SmsTemplate smsTemplate;

    @Test
    public void testSend() throws Exception {
        smsTemplate.sendSms("xxxxxxxx","1234");
    }

}
