package com.tanhua.dubbo.mappers;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tanhua.model.domain.BlackList;

public interface BlackListMapper extends BaseMapper<BlackList> {
}
