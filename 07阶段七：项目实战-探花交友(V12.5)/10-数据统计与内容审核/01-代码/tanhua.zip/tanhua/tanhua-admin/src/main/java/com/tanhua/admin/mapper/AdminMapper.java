package com.tanhua.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tanhua.model.domain.Admin;


public interface AdminMapper extends BaseMapper<Admin> {
}
